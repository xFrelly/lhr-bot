const Times = require('../../schemas/timeDb');  // Correct the path if necessary

module.exports = async (userId, guildId) => {
    try {
        const storedTime = await Times.findOne({ userId, guildId });
        if (!storedTime) {
            return false;
        }
        return storedTime;
    } catch (error) {
        console.error('Error getting times:');
    }
};
