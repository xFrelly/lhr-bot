const chalk = require('chalk')

module.exports = {
    name: 'disconnected',
    execute () {
            console.log(chalk.red("[Veritabanı Durumu] = Bağlantıdan Çıktı."))
     },
};