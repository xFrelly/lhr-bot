const chalk = require('chalk')

module.exports = {
    name: 'connecting',
    async execute () {
            console.log(chalk.blue("[Veritabanı Durumu] = Bağlanıyor..."))
     },
};