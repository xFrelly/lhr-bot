const { PermissionsBitField, ChannelType } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        const guild = client.guilds.cache.get('1248720429640581282'); // Replace with your guild ID

        // Fetch the bot's member
        const botMember = guild.members.cache.get(client.user.id);

        // Check if the bot has the necessary permissions
        if (!botMember.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            console.error('I do not have permission to manage channels.');
            return;
        }

        // Check if the channel already exists
        const existingChannel = guild.channels.cache.find(channel => channel.name.startsWith('Kişi Sayısı:'));
        if (existingChannel) {
            console.log('Channel already exists.');
            return;
        }

        // Create a voice channel
        try {
            const voiceChannel = await guild.channels.create({
                name: `Kişi Sayısı: ${guild.memberCount}`,
                type: ChannelType.GuildVoice, // Use ChannelType.GuildVoice for voice channels
                permissionOverwrites: [
                    {
                        id: guild.id,
                        allow: [PermissionsBitField.Flags.Connect],
                        deny: [PermissionsBitField.Flags.Speak],
                    },
                ],
            });

            console.log(`Voice channel ${voiceChannel.name} created successfully!`);
        } catch (error) {
            console.error('There was an error creating the voice channel:', error);
        }
    },
};
