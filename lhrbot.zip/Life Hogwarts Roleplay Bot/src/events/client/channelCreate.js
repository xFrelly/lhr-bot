module.exports = {
    name: 'channelCreate',
        async execute(client, message) {
            
        }
}