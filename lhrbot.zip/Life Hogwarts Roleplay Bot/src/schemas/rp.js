const { Schema, model, Types } = require('mongoose');

const rpSchema = new Schema({
    _id: { type: Types.ObjectId, auto: true },
    userId: String,
    guildId: String,
    points: { type: Number, default: 0 },
    channels: {type: [String], default: []},
    lastChannel: { type: String, default: ''}
}, { collection: 'rps' });

module.exports = model('Rp', rpSchema);
