const { Schema, model, Types } = require('mongoose');

const balanceSchema = new Schema({
    _id: { type: Types.ObjectId, auto: true },
    userId: String,
    guildId: String,
    balance: { type: Number, default: 0 },
}, { collection: 'balances' });

module.exports = model('Balance', balanceSchema);
