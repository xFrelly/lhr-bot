const { Schema, model, Types } = require('mongoose');

const timeSchema = new Schema({
    _id: Schema.Types.ObjectId,
    userId: String,
    guildId: String,
    muteUntil: Date
});

module.exports = model('Times', timeSchema, 'timeDb');
