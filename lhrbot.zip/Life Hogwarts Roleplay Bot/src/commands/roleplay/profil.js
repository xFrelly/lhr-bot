const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const getBalance = require('../../functions/economy/getBalance');
const getRp = require('../../functions/roleplay/getRp');
const getLevel = require('../../functions/leveling/getLevel');

module.exports = {
    name: "profil",
    data: new SlashCommandBuilder()
        .setName('profil')
        .setDescription('Size profilinizi gösterir.'),

    async execute(interaction, message) {
        if(message.content == "!profil") return;
        const user = interaction.user;
        const storedRp = await getRp(user.id, interaction.guild.id);
        const member = await interaction.guild.members.fetch(user.id);
        const roleNames = ["Gryffindor", "Slytherin", "Ravenclaw", "Hufflepuff"];
        const userHouse = member.roles.cache.find(role => roleNames.includes(role.name));
        const bakiye = await getBalance(user.id, interaction.guild.id)
        const storedLevel = await getLevel(user.id, interaction.guild.id)
        let requiredXp = 500 * Math.pow(3, storedLevel.level);
        let last = interaction.guild.channels.cache.get(storedRp.lastChannel)
        if(typeof last === 'undefined') last = "Yok.";
        if(typeof storedRp.points === 'undefined') storedRp.points = 0;
        if(typeof bakiye.balance === 'undefined') bakiye.balance = 0;
        if(typeof storedLevel.level === 'undefined') storedLevel.level = 0;
        if(typeof storedLevel.xp === 'undefined') storedLevel.xp = 0;

        await interaction.deferReply();

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`Profil - ${user.username}`)
            .setDescription(`İşte profil bilgileriniz, <@${user.id}>:`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields([
                {
                    name: "Kullanıcı İsmi:",
                    value: `<@${user.id}>`,
                    inline: true
                },
                {
                    name: "Bulunduğunuz Bina <:5_sapka:1248971340048891915>",
                    value: userHouse ? userHouse.name : "Rol bulunamadı",
                    inline: true
                },
                {
                    name: "Sunucuya Katılma Tarihiniz:",
                    value: member.joinedAt.toDateString(),
                    inline: true
                },
                {
                    name: "Bakiyeniz:",
                    value: `${bakiye.balance} Galleon :coin:`,
                    inline: true
                },
                {
                    name: "Roleplay Puanınız:",
                    value: `${storedRp.points} Puan <a:pembis_3:1250410253967687732>`,
                    inline: true
                },
                {
                    name: "Son RP yaptığınız kanal:",
                    value: `${last}`,
                    inline: true
                },
                {
                    name: `Seviyeniz ve XP'niz`,
                    value: `**${storedLevel.level.toLocaleString()}** Seviye - **${storedLevel.xp.toFixed(1)}**/**${requiredXp.toFixed(1)}** xp`
                },
            ])
            .setTimestamp()
            .setFooter({ text: `Profil Bilgileri - ${user.username}`, iconURL: user.displayAvatarURL({ dynamic: true }) });

        // Edit the original deferred reply with the embed containing the profile information
        await interaction.editReply({ embeds: [embed] });
    },
};
