const getLevel = require("../../functions/leveling/getLevel");
const { EmbedBuilder, Embed } = require('discord.js');

module.exports = {
    name: "lvllist",
    description: "Sunucunun Seviye sıralamasını gösterir.",
    aliases: ["seviyelistesi", "seviyeliste", "levellist", "slist", "xplist"],
    async execute(client, message, args) {
        try {
            // Fetch all members and their Level
            let levelList = await Promise.all(message.guild.members.cache
                .filter(member => !member.user.bot)
                .map(async member => {
                    const level = await getLevel(member.user.id, message.guild.id);
                    return { member, level: level || 0 };
                })
            );

            // Sort members by Level in descending order
            levelList = levelList.sort((a, b) => b.level - a.level);

            // Create a list of the top 10 members
            let list = '';
            for (let i = 0; i < Math.min(10, levelList.length); i++) {
                if (levelList[i].level > 0) {
                    list += `**${i + 1}**: <@${levelList[i].member.user.id}> | ${levelList[i].level.level.toLocaleString()} Seviye\n`;
                }
            }

            if (!list) {
                list = 'Henüz yeterli sayıda tecrübe puanı alan yok.\n(Minimum 10 kişi)';
            }

            const embed = new EmbedBuilder()
                .setTitle('LHR Seviye Sıralaması <a:pembis_5:1250410058144284713>')
                .setDescription(list)
                .setColor('#00FF00');

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error generating Level list:', error);
            message.channel.send('Seviye sıralamasını gösterirken bir hata oluştu.');
        }
    },
};
