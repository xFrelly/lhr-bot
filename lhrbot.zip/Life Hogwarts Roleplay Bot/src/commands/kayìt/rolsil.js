const { SlashCommandBuilder , PermissionsBitField} = require("discord.js");

module.exports = {
    name: "rolsil",
    data: new SlashCommandBuilder()
    .setName("rolsil")
    .setDescription("Belirtilen kullanıcıya istenilen rolü siler.")
    .addUserOption(option => option.setName("kullanici").setDescription("Kullanıcıyı seçiniz.").setRequired(true))
    .addRoleOption(option => option.setName("rol").setDescription("Silinecek rolü seçiniz.").setRequired(true)),
    async execute(interaction, message) {
        if(message.content == "!rolsil") return;
        const member = interaction.options.getMember("kullanici")
        const rol = interaction.options.getRole("rol")
        try {
            if(!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                interaction.reply("Bu rolü kullanmak için gerekli izne sahip değilsin!")
            }
            await member.roles.remove(rol)
        await interaction.reply(`*${member} adlı kullanıcıdan ${rol} rolü silindi.*`)
        } catch (error) {
            console.log(error)
        }
        
    }
}