const { PermissionsBitField } = require('discord.js');

module.exports = {
    name: "isim",
    description: "Belirtilen kullanıcının ismini değiştirir.",
    aliases: ["isimdeğiştir", "nickname", "nick"],
    async execute(client, message, args) {
        // Check if the member has the necessary permissions
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageNicknames) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.channel.send('Bu komutu kullanmak için yetkin yok.');
        }

        // Get the mentioned user and new nickname from the arguments
        const member = message.mentions.members.first();
        if (!member) {
            return message.channel.send('Lütfen ismi değiştirilecek kullanıcıyı belirtin.');
        }

        const newNick = args.slice(1).join(" ");
        if (!newNick) {
            return message.channel.send('Lütfen yeni bir isim belirtin.');
        }

        // Attempt to change the nickname
        try {
            await member.setNickname(newNick);
            message.channel.send(`${member.user.username} kullanıcısının ismi başarıyla ${newNick} olarak değiştirildi.`);
        } catch (error) {
            console.error('Error changing nickname:', error);
            message.channel.send('İsmi değiştirirken bir hata oluştu.');
        }
    }
};
